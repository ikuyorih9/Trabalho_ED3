#ifndef __MENSAGENS_ERRO_H__
#define __MENSAGENS_ERRO_H__

void imprimeErroRRN();
void imprimeErroArquivo();
void imprimeErroArquivo_2();
void registroNaoAlocado();
void imprimeErroEscrita(int offset);

#endif