#ifndef __MENSAGENS_ERRO_H__
#define __MENSAGENS_ERRO_H__

void imprimeErroRRN();
void imprimeErroArquivo();
void registroNaoAlocado();

#endif