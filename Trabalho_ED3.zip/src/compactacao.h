#ifndef COMPACTACAO_H
#define COMPACTACAO_H

void compactacao(const char * nomeArquivo);

#endif