#ifndef CREATE_INDEX_H
#define CREATE_INDEX_H

void createIndex(const char * nomeEntrada, const char * nomeSaida);

#endif