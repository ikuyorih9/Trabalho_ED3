#ifndef GERAR_GRAFO_H
#define GERAR_GRAFO_H

void gerarGrafo(const char * nomeArquivo);

#endif