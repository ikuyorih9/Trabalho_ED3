#ifndef MENOR_VELOCIDADE_H
#define MENOR_VELOCIDADE_H

void menorVelocidade(const char * nomeArquivo);

#endif