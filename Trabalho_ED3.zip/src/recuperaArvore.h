#ifndef RECUPERA_ARVORE_H
#define RECUPERA_ARVORE_H

void recuperaArvore(const char * nomeArquivoRegistro, const char * nomeArquivoArvore);

#endif