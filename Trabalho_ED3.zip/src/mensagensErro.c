#include <stdio.h>

void imprimeErroRRN(){
    printf("Nao foi possivel ler o arquivo.\n");
}

void imprimeErroArquivo(){
    printf("Falha no processamento do arquivo.\n");
}

void registroNaoAlocado(){
    printf("Registro inexistente.\n");
}