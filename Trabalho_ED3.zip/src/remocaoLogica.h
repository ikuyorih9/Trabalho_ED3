#ifndef REMOCAO_LOGICA_H
#define REMOCAO_LOGICA_H

void remocaoLogica(const char * nomeArquivo);

#endif