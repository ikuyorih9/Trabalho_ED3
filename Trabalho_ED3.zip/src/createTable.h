#ifndef CREATE_TABLE_H
#define CREATE_TABLE_H

#include <stdio.h>

void createTable(const char * nomeEntrada, const char * nomeSaida);

#endif