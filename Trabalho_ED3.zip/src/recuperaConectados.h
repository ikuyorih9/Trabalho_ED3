#ifndef RECUPERA_CONECTADOS_H
#define RECUPERA_CONECTADOS_H

void recuperaConectados(const char * nomeArquivo1, const char * nomeArquivo2, const char * nomeCampo1, const char * nomeCampo2, const char * nomeArquivoIndice2);

#endif