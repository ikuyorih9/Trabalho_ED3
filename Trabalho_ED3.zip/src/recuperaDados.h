#ifndef RECUPERA_DADOS_H
#define RECUPERA_DADOS_H

void recuperaDados(const char * nomeArquivo);

#endif