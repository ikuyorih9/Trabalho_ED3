#ifndef BUSCAR_REGISTROS_H
#define BUSCAR_REGISTROS_H

void buscarRegistros(const char * nomeArquivo);

#endif