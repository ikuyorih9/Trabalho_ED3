#ifndef CONTAGEM_CICLOS_H
#define CONTAGEM_CICLOS_H

void contagemCiclos(const char * nomeArquivo);

#endif