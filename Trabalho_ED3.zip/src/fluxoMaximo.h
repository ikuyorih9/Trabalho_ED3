#ifndef FLUXO_MAXIMO_H
#define FLUXO_MAXIMO_H

void fluxoMaximo(const char * nomeArquivo);

#endif