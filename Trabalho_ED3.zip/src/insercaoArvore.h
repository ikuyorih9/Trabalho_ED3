#ifndef INSERCAO_ARVORE_H
#define INSERCAO_ARVORE_H

void insercaoArvore(const char * nomeArquivoRegistro, const char * nomeArquivoArvore);

#endif