#ifndef IMPRESSAO_REGISTROS_H
#define IMPRESSAO_REGISTROS_H

void impressaoRegistros(const char * nomeArquivo);

#endif