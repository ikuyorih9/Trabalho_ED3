#ifndef LIMPAR_BUFFER_H
#define LIMPAR_BUFFER_H

void limparBuffer();

#endif